#include <stdio.h> 
float average(float age[]); 
int main() 
{ 
float avg, age[] = {16 17 18 19 20}; 
avg = average(age); /* Only name of array is passed as rgument. */ 
printf("Average age=%.2f", avg); 
return 0; 
}
float average(float age[]) 
{ 

    
    
    
}