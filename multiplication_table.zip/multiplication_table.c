#include<stdio.h>
int main()
{
    int m,n;
    printf("ENTER THE TABLE NUMBER:");
    scanf("%d",&m);
    for(n=1;n<=12;n++)
    {
        printf("%dX%d=%d",m,n,m*n);
        printf("\n");
    }
    return 0;
}